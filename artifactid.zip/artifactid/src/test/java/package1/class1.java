package package1;

import static org.testng.Assert.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;


public class class1 {

	@FindBy(linkText = "I'm Feeling Lucky")
	WebElement test;
	
	@Test()
	public void ahamed() throws InterruptedException {
		// TODO Auto-generated method stub
		System. setProperty("webdriver.chrome.driver", "D:\\Desktop\\chromedriver.exe");
		// Initialize browser.
		ChromeDriver driver= new ChromeDriver();
		driver.navigate().to("http://www.google.com");
		Thread.sleep(5000);
		test.click();
		//driver.close();
		//assertTrue(false); 
	}

}
